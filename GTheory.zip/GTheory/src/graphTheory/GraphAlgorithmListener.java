/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package graphTheory;

/**
 *
 * @author user
 */
public interface GraphAlgorithmListener {
    public void nodeVisited(NodeEvent e);
}
